// Get the HTML elements
const taskInput = document.getElementById("taskInput");
const addTaskButton = document.getElementById("addTaskButton");
const pendingTasksList = document.getElementById("pendingTasksList");
const completedTasksList = document.getElementById("completedTasksList");

// Store tasks
let pendingTasks = [];
let completedTasks = [];

// Function to add task
function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    const task = {
        text: taskText,
        dateAdded: new Date().toLocaleString(),
        isCompleted: false,
    };

    // Add task to pendingTasks array
    pendingTasks.push(task);

    // Reset input field
    taskInput.value = "";

    // Re-render tasks
    renderTasks();
}

// Function to mark task as complete
function completeTask(index) {
    const task = pendingTasks.splice(index, 1)[0];
    task.isCompleted = true;
    task.completedDate = new Date().toLocaleString();
    completedTasks.push(task);
    renderTasks();
}

// Function to delete task
function deleteTask(index, isCompleted) {
    if (isCompleted) {
        completedTasks.splice(index, 1);
    } else {
        pendingTasks.splice(index, 1);
    }
    renderTasks();
}

// Function to edit task
function editTask(index, isCompleted) {
    const newText = prompt("Edit the task:", isCompleted ? completedTasks[index].text : pendingTasks[index].text);
    if (newText) {
        if (isCompleted) {
            completedTasks[index].text = newText;
        } else {
            pendingTasks[index].text = newText;
        }
        renderTasks();
    }
}

// Function to render tasks
function renderTasks() {
    // Clear both task lists
    pendingTasksList.innerHTML = "";
    completedTasksList.innerHTML = "";

    // Render pending tasks
    pendingTasks.forEach((task, index) => {
        const li = document.createElement("li");
        li.innerHTML = `
            <span>${task.text} (Added: ${task.dateAdded})</span>
            <div>
                <button class="complete" onclick="completeTask(${index})">Complete</button>
                <button onclick="editTask(${index}, false)">Edit</button>
                <button onclick="deleteTask(${index}, false)">Delete</button>
            </div>
        `;
        pendingTasksList.appendChild(li);
    });

    // Render completed tasks
    completedTasks.forEach((task, index) => {
        const li = document.createElement("li");
        li.innerHTML = `
            <span>${task.text} (Completed: ${task.completedDate})</span>
            <div>
                <button onclick="editTask(${index}, true)">Edit</button>
                <button onclick="deleteTask(${index}, true)">Delete</button>
            </div>
        `;
        completedTasksList.appendChild(li);
    });
}

// Add event listener to the Add Task button
addTaskButton.addEventListener("click", addTask);

// Initial render
renderTasks();
